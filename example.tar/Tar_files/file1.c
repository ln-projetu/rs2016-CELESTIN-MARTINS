cheval
poney

;)